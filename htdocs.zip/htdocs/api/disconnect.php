<?php

include "../includes/db_lib.php";


//$token = $_REQUEST['tok'];
$check = API::stop_session();

echo $check; 
?>
